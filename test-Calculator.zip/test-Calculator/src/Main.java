import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

//
public class Main implements ActionListener{
	
	JTextField tf;
	JButton bt;
	//
	String btText[] =   {"7","8","9","/",
						"4","5","6","*",
						"3","2","1","-",
					    "0",".","=","+",};
	String strA = "";
	String strB = "";
	char operator = '~';
	String StrC = "";
	public static void main(String args[] ){
		Main app = new Main();
		
		app.go();

		
		
		
	}
	//
		 void go(){
			 
			 JFrame frame = new JFrame("Calculator");
			 frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			 
			 
			 tf = new JTextField();
			 tf.setPreferredSize(new Dimension(400,60));
			 
			 bt = new JButton();
			 frame.getContentPane().add(tf,BorderLayout.NORTH);
			 frame.getContentPane().add(bt, BorderLayout.CENTER);
//			 frame.getContentPane().add
			 JPanel p = new JPanel();
			 p.setLayout(new GridLayout(4,4));
			 for(int i=0;i<16;i++){
				 
				 JButton bt = new JButton(btText [i]);
				 p.add(bt);
				 bt.addActionListener(this);
				 
			 }
			 frame.getContentPane().add(p,BorderLayout.CENTER);
			 frame.setSize(300, 400);
			 frame.setVisible(true);
			 
			 
		 }
		@Override
		public void actionPerformed(ActionEvent e) {
			
			String action = e.getActionCommand();
			
			char act =action.charAt(0);
			
			if(act>='0' && act<='9'){
				if(operator=='~'){
					strA += action;
					tf.setText(strA);
				}
				else{ 
					strB += action;
					tf.setText(strB);
				}
			
			
			}
			else if(act=='+'|| act=='-' || act=='*' || act=='/')
			{
					operator = act;
					tf.setText(strA+act);
					
				}
			
			
			else if(act=='='){
				if(operator=='+'){
					int a=Integer.parseInt(strA);
					int b=Integer.parseInt(strB);
					int c=a+b;
					tf.setText(c+"");
				}
					
				
					if(operator=='-')
					{
						int a=Integer.parseInt(strA);
						int b=Integer.parseInt(strB);				
						int c=a-b;
						tf.setText(c+"");						
					}			
			
					if(operator=='*')
					{
						int a=Integer.parseInt(strA);
						int b=Integer.parseInt(strB);
						int c=a*b;
						tf.setText(c+"");	
						}	
						
				
					if(operator=='/')
					{
						int a=Integer.parseInt(strA);
						int b=Integer.parseInt(strB);
						int c=a/b;
						tf.setText(c+"");		
							}	
					operator='~';
					strA="";
					strB="";
				}
					
		}
}
		

